extends Control
## 对话优先：在场人物用头顶气泡；旁白统一在顶部，轻透明底衬。
const FONT := preload("res://hongyuan/fonts/dialogue_font.tres")
const NAMES := {"ayu": "阿鱼", "toretto": "Toretto", "axiao": "阿晓"}
const PAPER := Color("#fff1d5")
const INK := Color("#281a1a")
const WOOD := Color("#50332a")
const RED := Color("#5e2929")
static var narration_top := 54.0
static var safe_top := 0.0
var text := ""
var speaker := "narrator"
var speaker_anchor := Vector2(-1, -1)

static func perspective_badge_top() -> float:
	return maxf(safe_top + 8.0, minf(12.0, narration_top - 30.0))

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	size = Vector2(360, 640)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _draw() -> void: draw_caption(self, text, speaker, -1, false, speaker_anchor)

const AVATAR_FILES := {
	"ayu": "res://hongyuan/assets/ayu_avatar.png",
	"toretto": "res://hongyuan/assets/toretto_avatar.png",
	"axiao": "res://hongyuan/assets/axiao_avatar.png",
}
static var avatar_cache: Dictionary = {}

static func avatar(who: String) -> Texture2D:
	if not AVATAR_FILES.has(who): return null
	if not avatar_cache.has(who) and ResourceLoader.exists(AVATAR_FILES[who]):
		avatar_cache[who] = load(AVATAR_FILES[who])
	return avatar_cache.get(who)

static func draw_low_narration(ci: CanvasItem, text: String, shown: int) -> void:
	var full := wrap_text(text, 294.0, 16)
	var height := maxi(54, (full.count("\n") + 1) * 20 + 22)
	var box := Rect2(21, 567 - height, 318, height)
	var skin := StyleBoxFlat.new()
	skin.bg_color = Color(0.11, 0.09, 0.12, 0.90)
	skin.set_border_width_all(1)
	skin.set_corner_radius_all(6)
	skin.border_color = Color("#b69766")
	ci.draw_style_box(skin, box)
	ci.draw_multiline_string(FONT, box.position + Vector2(12, 21), wrap_text(text.left(shown), 294.0, 16),
		HORIZONTAL_ALIGNMENT_CENTER, 294.0, 16, -1, PAPER)

static func _display_text(full_text: String, who: String, width: float, visible_characters := -1) -> String:
	var shown := full_text if visible_characters < 0 else full_text.substr(0, visible_characters)
	var font_size := 16 if NAMES.has(who) else 15
	return wrap_text(shown,width,font_size)

static var codas: Dictionary = {}

static func chapter_coda(id: String) -> Dictionary:
	if codas.is_empty():
		codas = JSON.parse_string(FileAccess.get_file_as_string("res://hongyuan/interludes.json"))
	var entry = codas.get(id, {})
	return {"pages": entry} if entry is Array else entry

static func wrap_text(shown: String, width: float, font_size: int) -> String:
	if width <= 0: return shown
	# Web's reduced TextServer does not reliably find Chinese word boundaries.
	# Measure each line explicitly so the identical copy fits native and Web.
	var lines: Array[String] = []
	for paragraph in shown.split("\n"):
		var line := ""
		for character in paragraph:
			if not line.is_empty() and FONT.get_string_size(line+character,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x > width:
				lines.append(line)
				line = ""
			line += character
		lines.append(line)
	return "\n".join(lines)

static func caption_rect(full_text: String, who: String, anchor := Vector2(-1, -1)) -> Rect2:
	full_text = _strip_emoji(full_text)
	var named := NAMES.has(who)
	if not named:
		var height := FONT.get_multiline_string_size(_display_text(full_text, who, 308), HORIZONTAL_ALIGNMENT_CENTER, 308, 15).y + 18
		return Rect2(14, narration_top, 332, maxf(38, height))
	if anchor.x >= 0:
		var width := clampf(FONT.get_string_size(full_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x + 28, 76, 260)
		var height := FONT.get_multiline_string_size(_display_text(full_text, who, width - 28), HORIZONTAL_ALIGNMENT_LEFT, width - 28, 16).y + 28
		var top := maxf(safe_top + 12.0, maxf(narration_top - 40.0, anchor.y - height - 20.0))
		return Rect2(clampf(anchor.x - width * 0.5, 12, 348 - width), top, width, height)
	var height := FONT.get_multiline_string_size(_display_text(full_text, who, 244), HORIZONTAL_ALIGNMENT_LEFT, 244, 16).y + 38
	return Rect2(14, 604 - maxf(height, 88), 332, maxf(height, 88))

## 表情字符在 Web 包里不可靠（字体回退会画空），换成占位全角空格，字画完后在原位置贴图标
const EMOJI := {"🤔": "res://hongyuan/assets/think.svg", "😂": "res://hongyuan/assets/laugh.svg"}

static func _strip_emoji(t: String) -> String:
	for e in EMOJI:
		t = t.replace(e, "   ")
	return t

static func draw_caption(ci: CanvasItem, full_text: String, who: String, visible_characters := -1, next_hint := false, anchor := Vector2(-1, -1)) -> void:
	var icons: Array = []
	for e in EMOJI:
		var at := full_text.find(e)
		while at >= 0:
			icons.append([at, EMOJI[e]])
			at = full_text.find(e, at + 1)
	if not icons.is_empty():
		var raw := full_text
		full_text = _strip_emoji(full_text)
		_draw_caption_text(ci, full_text, who, visible_characters, next_hint, anchor)
		# 只处理一行内的表情（本作的表情都在短句末尾）
		var named := NAMES.has(who)
		var bubble := named and anchor.x >= 0
		var box := caption_rect(full_text, who, anchor)
		var inset := 14.0 if bubble else (70.0 if named else 12.0)
		var width := box.size.x - inset - (14 if bubble else (18 if named else 12))
		var fs := 16 if named else 15
		# 居中对齐时末尾空格不算宽度
		var line_w := FONT.get_string_size(full_text.strip_edges(false, true), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var x0 := box.position.x + inset + (0.0 if named else maxf(0.0, (width - line_w) * 0.5))
		for ic in icons:
			if visible_characters >= 0 and visible_characters <= int(ic[0]):
				continue
			var before := FONT.get_string_size(full_text.substr(0, int(ic[0])), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
			_draw_face(ci, Vector2(x0 + before + fs * 0.5 + 3, box.position.y + ((22 if not bubble else 26) if named else 23) - fs * 0.35), fs * 0.5, str(ic[1]))
		return
	_draw_caption_text(ci, full_text, who, visible_characters, next_hint, anchor)

## 直接画小表情（SVG 在部分 Web 环境会画成白块）
static func _draw_face(ci: CanvasItem, c: Vector2, rad: float, kind: String) -> void:
	var ink := Color("#54353c")
	ci.draw_circle(c, rad, Color("#f6c568"))
	if kind.ends_with("think.svg"):
		ci.draw_circle(c + Vector2(-rad * 0.35, -rad * 0.15), rad * 0.13, ink)
		ci.draw_circle(c + Vector2(rad * 0.35, -rad * 0.15), rad * 0.13, ink)
		ci.draw_line(c + Vector2(-rad * 0.6, -rad * 0.5), c + Vector2(-rad * 0.15, -rad * 0.55), ink, 1.0)
		ci.draw_line(c + Vector2(-rad * 0.25, rad * 0.4), c + Vector2(rad * 0.3, rad * 0.35), ink, 1.0)
		ci.draw_circle(c + Vector2(-rad * 0.55, rad * 0.85), rad * 0.3, Color("#e8a94c"))
	else:
		ci.draw_line(c + Vector2(-rad * 0.55, -rad * 0.2), c + Vector2(-rad * 0.15, -rad * 0.35), ink, 1.0)
		ci.draw_line(c + Vector2(rad * 0.15, -rad * 0.35), c + Vector2(rad * 0.55, -rad * 0.2), ink, 1.0)
		ci.draw_circle(c + Vector2(0, rad * 0.3), rad * 0.35, Color("#633a42"))
		ci.draw_circle(c + Vector2(-rad * 0.95, 0), rad * 0.22, Color("#74c9e6"))
		ci.draw_circle(c + Vector2(rad * 0.95, 0), rad * 0.22, Color("#74c9e6"))

static func _draw_caption_text(ci: CanvasItem, full_text: String, who: String, visible_characters := -1, next_hint := false, anchor := Vector2(-1, -1)) -> void:
	var named := NAMES.has(who)
	var bubble := named and anchor.x >= 0
	var box := caption_rect(full_text, who, anchor)
	var panel := StyleBoxFlat.new()
	# 旁白压在亮背景（天空、海面、楼面）上也要看得清：深色半透明底 + 细金边
	panel.bg_color = PAPER if named else Color(0.14, 0.10, 0.08, 0.88)
	panel.set_corner_radius_all(12 if named else 6)
	if named:
		panel.border_color = WOOD
		panel.set_border_width_all(2)
	else:
		panel.border_color = Color("#c9a66b", 0.55)
		panel.set_border_width_all(1)
	ci.draw_style_box(panel, box)
	if bubble:
		if anchor.y > box.end.y + 6.0:
			var tail_x := clampf(anchor.x, box.position.x + 18, box.end.x - 18)
			var a := Vector2(tail_x - 7, box.end.y - 2)
			var b := Vector2(tail_x + 7, box.end.y - 2)
			var tip := Vector2(anchor.x, minf(anchor.y - 3, box.end.y + 17))
			ci.draw_colored_polygon(PackedVector2Array([a, b, tip]), PAPER)
			ci.draw_polyline(PackedVector2Array([a, tip, b]), WOOD, 2)
		# 气泡左上角的小名牌：两人并排时一眼看出是谁在说
		var who_name: String = NAMES[who]
		var name_w := FONT.get_string_size(who_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 11).x + 12
		var name_tag := Rect2(box.position + Vector2(8, -9), Vector2(name_w, 16))
		var name_skin := StyleBoxFlat.new()
		name_skin.bg_color = RED
		name_skin.set_corner_radius_all(8)
		ci.draw_style_box(name_skin, name_tag)
		ci.draw_string(FONT, name_tag.position + Vector2(0, 12), who_name, HORIZONTAL_ALIGNMENT_CENTER, name_tag.size.x, 11, PAPER)
	var inset := 14.0 if bubble else (70.0 if named else 12.0)
	if named and not bubble:
		# 头像在左，名字写在头像正下方，不压着对话。
		var face := avatar(who)
		if face: ci.draw_texture_rect(face, Rect2(box.position + Vector2(14, 10), Vector2(44, 44)), false)
		var label: String = NAMES[who]
		var tag := Rect2(box.position + Vector2(6, 58), Vector2(60, 20))
		var skin := StyleBoxFlat.new()
		skin.bg_color = RED
		skin.set_corner_radius_all(10)
		ci.draw_style_box(skin, tag)
		ci.draw_string(FONT, tag.position + Vector2(0, 15), label, HORIZONTAL_ALIGNMENT_CENTER, tag.size.x, 12, PAPER)
	var width := box.size.x - inset - (14 if bubble else (18 if named else 12))
	var shown := _display_text(full_text, who, width, visible_characters)
	var at := box.position + Vector2(inset, (22 if not bubble else 26) if named else 23)
	var align := HORIZONTAL_ALIGNMENT_LEFT if named else HORIZONTAL_ALIGNMENT_CENTER
	if not named:
		ci.draw_multiline_string(FONT, at + Vector2(1, 1), shown, align, width, 15, -1, Color(0, 0, 0, 0.6))
	ci.draw_multiline_string(FONT, at, shown, align, width, 16 if named else 15, -1, INK if named else Color(1, 0.97, 0.9, 0.9))
	if next_hint and named and not bubble:
		ci.draw_colored_polygon(PackedVector2Array([box.end - Vector2(24, 17), box.end - Vector2(14, 17), box.end - Vector2(19, 11)]), WOOD)
